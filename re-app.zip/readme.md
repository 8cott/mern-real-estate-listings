Project Title: 
Real Estate Listings MERN App

Technology:
I created this project using node.js, express.js with react views, and MongoDB. Full CRUD functionality.

Inspiration:
The inspiration for this app is that I am a real estate agent and use listing sites every day. I wanted to create a site to display my past and present listings.

Functionality:
You can create a new real estate listing, edit an existing listing, or delete a listing. 
There is a main index view with all listings in a table. 
There is also a show view, so you can view individual listings with more information. 

Scott Rubin